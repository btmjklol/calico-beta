// Calico works offline once it has been opened: everything it fetched is kept and served from here,
// and refreshed in the background whenever the network is there. The teacher list is always fetched fresh.
const CACHE = 'calico-v2'; // v1 was the copy at /calico/, before the app moved to /calico/app/
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== location.origin || req.url.includes('teachers.json')) return;
  e.respondWith(caches.open(CACHE).then(async (cache) => {
    const hit = await cache.match(req);
    const fresh = fetch(req).then((res) => { if (res.ok) cache.put(req, res.clone()); return res; }).catch(() => hit);
    return hit ?? fresh;
  }));
});
