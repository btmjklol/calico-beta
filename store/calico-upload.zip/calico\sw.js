// The Calico app used to live at /calico/, kept offline by a worker at this address. The app moved to
// /calico/app/ (with its own worker), so this one only tidies up: it drops the old cache, steps aside,
// and reloads any page it was serving so people see the new home page instead of the old copy.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil((async () => {
  await caches.delete('calico-v1');
  await self.registration.unregister();
  for (const c of await self.clients.matchAll({ type: 'window' })) c.navigate(c.url);
})()));
